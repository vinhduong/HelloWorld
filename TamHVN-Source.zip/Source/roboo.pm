package roboo;
our $VERSION = '0.7';
use nginx;
use warnings;
use strict;
use Digest::SHA qw(sha1_hex);
use Net::IP::Match::Regexp qw(create_iprange_regexp match_ip);
use Crypt::Random qw(makerandom_octet);
use Compress::Zlib qw{compress};

my $settings = {};
my $valid_cookie;
sub handler ($) {
    my $request = shift;

    # Initialize
    init($request);

    # Refresh hash_input if needed
    $settings->{challenge_hash_input} = $request->variable('Roboo_challenge_hash_input') ? $request->variable('Roboo_challenge_hash_input') : $request->remote_addr;
    # Generate cookie
    $valid_cookie = generate_cookie($settings->{challenge_hash_input}, get_secret());
    
    # Proxy clients with valid cookies if exist
    if (valid_cookie($request)) {
        return 555;
    }
    
    # Cookie isn't valid or doesn't exist - begin challenge/response
    if ($request->request_method eq 'GET') { 
        challenge_GET($request);
    } elsif ($request->request_method eq 'POST') {
        # if this is a file upload, discard data and treat this as a GET (redirect to page)
        if (defined $request->header_in('Content-Type') && $request->header_in('Content-Type') =~ /multipart\/form-data/) {
            challenge_GET($request);
        } elsif ($request->has_request_body(\&challenge_POST)) {
            return OK;
        }
        return HTTP_BAD_REQUEST;
    }
}

# check if client cookie is valid
sub valid_cookie ($) {
    my $request = shift;

    return (defined($request->header_in('Cookie')) && $request->header_in('Cookie') =~ "$settings->{cookie_name}=$valid_cookie");
}

# Initialize Roboo settings and generate secret key
sub init ($) {
    my $request = shift;
    
    if (not %{$settings}) {
        # Populate settings from Nginx configuration
        $settings->{cookie_name} = defined $request->variable('Roboo_cookie_name') ? $request->variable('Roboo_cookie_name') : 'Anti-Robot';
        $settings->{validity_window} = defined $request->variable('Roboo_validity_window') ? $request->variable('Roboo_validity_window') : 600;
        $settings->{challenge_modes} = defined $request->variable('Roboo_challenge_modes') ? $request->variable('Roboo_challenge_modes') : 'SWF';
        $settings->{charset} = defined $request->variable('Roboo_charset') ? $request->variable('Roboo_charset') : 'UTF-8';
        
        # Get RANDBITS for get_timeseed
        use Config;
        $settings->{internal_randbits} = $Config{randbits};
        no Config;
        # Get master process id
        $settings->{internal_masterpid} = getppid();
        # Generate/synchronize random secret
        $settings->{internal_secret} = generate_secret($request);
    }
}

# Challenge cookie value is a time-based SHA1 hash of - secret, client IP, and optionally Host & User-Agent header values
sub generate_cookie (@) {
    return sha1_hex(@_, get_timeseed());
}

sub generate_secret ($) {
    use IPC::SysV qw(IPC_CREAT);
    use IPC::SharedMem;
    my $request = shift;

    my $shared = IPC::SharedMem->new(13373, 128, IPC_CREAT | 0600) or die "Cannot interface with shared memory: $_";
    $shared->attach;

    if ($shared->read(0,128) !~ /^$settings->{internal_masterpid}:/s) {
        my $secret = $request->variable('Roboo_secret') ? $request->variable('Roboo_secret') : makerandom_octet(Length => 64, Strength => 0); 
        $shared->write("$settings->{internal_masterpid}:$secret",0,128);
    }

    no IPC::SysV qw(IPC_CREAT);
    no IPC::SharedMem;

    return $shared;
}

sub get_secret () {
    $settings->{internal_secret}->read(0,128) =~ /^$settings->{internal_masterpid}:(.{64})/s;

    return $1;
}

sub get_timeseed () {
    return 1 unless $settings->{validity_window} > 0;
    my $valid_time = time();

    $valid_time = $valid_time - ($valid_time % $settings->{validity_window});
    srand($valid_time);

    return int(rand(2**$settings->{internal_randbits}-1));
}

# respond with a challenge for GET requests, triggering an automatic reload of the page 
sub challenge_GET ($) {
    my $request = shift;

    if ($settings->{challenge_modes} =~ 'JS') {
        challenge_GET_JS($request);
    } 
}

sub challenge_GET_JS ($) {
    my $request = shift;
    my $response = <<EOF;
<html>
<body onload="challenge();">
<script>
eval(function(p,a,c,k,e,r){e=function(c){return c.toString(a)};if(!''.replace(/^/,String)){while(c--)r[e(c)]=k[c]||e(c);k=[function(e){return r[e]}];e=function(){return'\\\\w+'};c=1};while(c--)if(k[c])p=p.replace(new RegExp('\\\\b'+e(c)+'\\\\b','g'),k[c]);return p}('1 6(){2.3=\\'4=5; 0-7=8; 9=/\\';a.b.c()}',13,13,'max|function|document|cookie|$settings->{cookie_name}|$valid_cookie|challenge|age|$settings->{validity_window}|path|window|location|reload'.split('|'),0,{}))
</script>
</body>
</html>
EOF
    $response =~ s/max/tax/ unless $settings->{validity_window} > 0;
    $request->send_http_header("text/html; charset=$settings->{charset}");
    $request->print($response);
    $request->rflush;
    return OK; 
}
# respond with a challenge for POST requests, triggering an automatic resubmission of the form 
sub challenge_POST ($) {
    my $request = shift;

    if ($settings->{challenge_modes} =~ 'JS') {
        challenge_POST_JS($request);
    } 
}

sub post_data_decode ($) {
    my $data = shift;

    $data =~ tr/+/ /;
    $data =~ s/%([a-fA-F0-9]{2})/pack("C", hex($1))/eg;
    $data =~ s/\x22/&quot;/g;
    
    return $data;
}

sub post_body_to_form ($) {
    my $body = shift;
    
    return '' unless (defined $body);

    # recover POST data
    my $form_variables = '';    
    my ($varname, $varvalue);
    foreach my $variable (split(/&/, $body)) {
        ($varname, $varvalue) = split(/=/, $variable);
        $varname = post_data_decode($varname);
        if (defined $varvalue) {
            $varvalue = post_data_decode($varvalue);
        } else {
            $varvalue = '';
        }
        $form_variables .= "<input type=\"hidden\" name=\"$varname\" value=\"$varvalue\">\n";
    }

    return $form_variables;
}

sub challenge_POST_JS ($) {
    my $request = shift;
    my $response = <<EOF;
<html>
<body onload="challenge();">
<script>
eval(function(p,a,c,k,e,r){e=function(c){return c.toString(a)};if(!''.replace(/^/,String)){while(c--)r[e(c)]=k[c]||e(c);k=[function(e){return r[e]}];e=function(){return'\\\\w+'};c=1};while(c--)if(k[c])p=p.replace(new RegExp('\\\\b'+e(c)+'\\\\b','g'),k[c]);return p}('d a(){1.e=\\'5=6; 7-8=9; 4=/\\';1.b.c=2.3.f+2.3.g;1.h[0].i()}',19,19,'|document|window|location|path|$settings->{cookie_name}|$valid_cookie|max|age|$settings->{validity_window}|challenge|response|action|function|cookie|pathname|search|forms|submit'.split('|'),0,{}))
</script>
<form name="response" method="post">
VARIABLES_PLACEHOLDER</form>
</body>
</html>
EOF
    # recover POST data
    my $form_variables = post_body_to_form($request->request_body);    
    $response =~ s/VARIABLES_PLACEHOLDER/$form_variables/;
    $response =~ s/max/tax/ unless $settings->{validity_window} > 0;
    
    $request->send_http_header("text/html; charset=$settings->{charset}");
    $request->print($response);
    $request->rflush;
    return OK;
}
1;
__END__
