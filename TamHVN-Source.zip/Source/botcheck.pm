package mycap;
our $VERSION = '0.01';

use nginx;
use warnings;
use GD::SecurityImage;
use Data::Dumper;
use Digest::MD5 'md5_hex';
use MIME::Base64;
use Net::IP::Match::Regexp qw(create_iprange_regexp match_ip);
use roboo;
use captchaddos;
use http302;
use strict;
my $settings = {};
sub handler {	
	my $r = shift;
	
	$settings->{whitelist} = defined $r->variable('Roboo_whitelist') ? $r->variable('Roboo_whitelist') : '';    
    # Generate whitelist arrays
    if ($settings->{whitelist} ne '') {
		my @whitelisted_networks = ($settings->{whitelist} =~ /IP\(([^)]+)\)/g);
		$settings->{whitelisted_networks} = create_iprange_regexp(@whitelisted_networks) unless (not scalar @whitelisted_networks);
        @{$settings->{whitelisted_useragents}} = ($settings->{whitelist} =~ /UA\('([^']+)'\)/g);
        @{$settings->{whitelisted_uris}} = ($settings->{whitelist} =~ /URI\('([^']+)'\)/g);
    }	
	
    if (whitelisted_network($r) or whitelisted_useragent($r) or whitelisted_uri($r)) {
        return 555;
    }
	if ($r->variable('Roboo_challenge_modes') =~ 'JS'){
		return roboo::handler($r);
	}
	if ($r->variable('Roboo_challenge_modes') =~ 'CAP'){
		return captchaddos::handler($r);
	}
	if ($r->variable('Roboo_challenge_modes') =~ 'HTTP302'){
		return http302::handler($r);
	}
	return 555;
}	
# check if client IP is whitelisted
sub whitelisted_network ($) {
    my $request = shift;
    
    return (defined $settings->{whitelisted_networks} && match_ip($request->remote_addr, $settings->{whitelisted_networks}));    
}

# check if client User-Agent value is whitelisted
sub whitelisted_useragent ($) {
    my $request = shift;

    if (defined $settings->{whitelisted_useragents} && defined $request->header_in('User-Agent')) {
        foreach my $UA (@{$settings->{whitelisted_useragents}}) {
            if ($request->header_in('User-Agent') =~ /$UA/) {
                return 1;
            }
        }
    }
    return 0;
}

# check if requested URI is whitelisted
sub whitelisted_uri ($) {
    my $request = shift;

    if (defined $settings->{whitelisted_uris}) {
        foreach my $URI (@{$settings->{whitelisted_uris}}) {
            if ($request->uri =~ /$URI/) {
                return 1;
            }
        }
    }
    return 0;
}
1;
__END__
