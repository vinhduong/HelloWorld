package captchaddos;
our $VERSION = '1.0';

use nginx;
use warnings;
use GD::SecurityImage;
use Data::Dumper;
use Digest::MD5 'md5_hex';
use Net::IP::Match::Regexp qw(create_iprange_regexp match_ip);
use MIME::Base64;
use strict;
use Socket;
my $settings = {};
my $valid_key_code;
sub handler {
	my $r = shift;					
	init($r);		
	return captchar($r);		
}	
sub init($){
	my $request = shift;    
    if (not %{$settings}) {		
		$settings->{cap_public_key_name} = defined $request->variable('cap_public_key_name') ? $request->variable('cap_public_key_name') : 'public_key';
		$settings->{cap_text_cap} = defined $request->variable('cap_text_cap') ? $request->variable('cap_text_cap') : 'txtcap';
		$settings->{cap_secret_key} = defined $request->variable('cap_secret_key') ? $request->variable('cap_secret_key') : '7895642UIVTextoper9';
		$settings->{cap_pass_key} = defined $request->variable('cap_pass_key') ? $request->variable('cap_pass_key') : '118945Uyo9uTSLcMOper7';
		
		$settings->{cap_trunc_amount} = defined $request->variable('cap_trunc_amount') ? $request->variable('cap_trunc_amount') : 300;
		$settings->{cap_trunc_valid_cookie_amount} = defined $request->variable('cap_trunc_valid_cookie_amount') ? $request->variable('cap_trunc_valid_cookie_amount') : 6000;
			
        # Populate settings from Nginx configuration
        $settings->{cookie_name} = defined $request->variable('Roboo_cookie_name') ? $request->variable('Roboo_cookie_name') : 'Anti-Robot';
        $settings->{validity_window} = defined $request->variable('Roboo_validity_window') ? $request->variable('Roboo_validity_window') : 600;        
        $settings->{whitelist} = defined $request->variable('Roboo_whitelist') ? $request->variable('Roboo_whitelist') : '';
        $settings->{charset} = defined $request->variable('Roboo_charset') ? $request->variable('Roboo_charset') : 'UTF-8';
        # Generate whitelist arrays
        if ($settings->{whitelist} ne '') {
            my @whitelisted_networks = ($settings->{whitelist} =~ /IP\(([^)]+)\)/g);
            $settings->{whitelisted_networks} = create_iprange_regexp(@whitelisted_networks) unless (not scalar @whitelisted_networks);
            @{$settings->{whitelisted_useragents}} = ($settings->{whitelist} =~ /UA\('([^']+)'\)/g);
            @{$settings->{whitelisted_uris}} = ($settings->{whitelist} =~ /URI\('([^']+)'\)/g);
        }
        # Get RANDBITS for get_timeseed
        use Config;
        $settings->{internal_randbits} = $Config{randbits};
        no Config;
        # Get master process id
        $settings->{internal_masterpid} = getppid();   		
    }
}
sub captchar($)
{	
	my $r = shift; 	
	my $trunc = int(time / $settings->{cap_trunc_amount});  	
	my $trunc_valid_cookie = int(time / $settings->{cap_trunc_valid_cookie_amount});  	
	$valid_key_code = validKey($r->remote_addr, $trunc_valid_cookie, $settings->{internal_masterpid} . $settings->{cap_pass_key} );		
	if ($r->header_in('Cookie') =~ "$settings->{cookie_name}=$valid_key_code")	{
		return 555;
	}
	if ($r->has_request_body(\&verify_Cap_Post)){
		return OK;
	}else{
		show_Cap($r);
		return OK;
	}	
	return HTTP_BAD_REQUEST;
}
sub show_Cap($){
	my $r = shift;			
	my $trunc = int(time / $settings->{cap_trunc_amount});  	
	my $public_key = '';
	my $response = '';						
	
	#no public key and answer. Show captchar
	my $random_key = generateRandomString();   
	my $image = GD::SecurityImage->new(
					width   => 160,
					height  => 60,
					lines   => 6,
					gd_font => 'giant',
				);
	$image->random( $random_key ) ;
	$image->create( normal => 'ec' );
	my($image_data, $mime_type, $random_number) = $image->out;
		
	#chuan bi image data cho display web
	$image_data= encode_base64($image_data);	
	
	#ma hoa public key		
	$public_key = encryptKey($r->remote_addr, $trunc .  $settings->{internal_masterpid}, $random_key, $settings->{cap_secret_key} );
	
	#generate captchar form
	$response = <<EOF2;   
<html>
<body>
<form name="response" method="post" style='position: fixed;top: 50%;left: 50%;margin-top: -50px;margin-left: -100px;'>
Vui lòng nhập mã số bên dưới<br/>
<img src="data:image/png;base64,$image_data"/>
<br/>
<input type='textbox' name='$settings->{cap_text_cap}' value='' placeholder='Điền lại mã bên trên'/><input type='submit' text='Submit'/><br/>
<input type='hidden' name='$settings->{cap_public_key_name}' value='$public_key'/><br/>
</form></body></html>
EOF2
	
	$r->send_http_header("text/html; charset=utf-8");		
	$r->print($response);		   
	$r->flush;					
	return OK;	
}
sub verify_Cap_Post($){
	my $r = shift;					
	my $trunc = int(time / $settings->{cap_trunc_amount});  	
	my $trunc_valid_cookie = int(time / $settings->{cap_trunc_valid_cookie_amount});  	
			
	my $answer_text = '';
	my $answer_key = '';
	my $public_key = '';
	my $response = '';
	
	if ($r->request_method eq 'POST'){						
		my ($varname, $varvalue);		
		foreach my $variable (split(/&/, $r->request_body)) {						
			($varname, $varvalue) = split(/=/, $variable);
			$varname = post_data_decode($varname);			
			if (defined $varvalue) {
				$varvalue = post_data_decode($varvalue);
				#trim value
				$varvalue =~ s/^\s+|\s+$//g; 
				#value max string lens
				$varvalue = substr( $varvalue, 0, 50 );
			} else {
				$varvalue = '';				
			}	    
			if ($varname eq $settings->{cap_text_cap}){
				if ($varvalue ne ''){
					$answer_text = $varvalue;					
				}		
			}
			if ($varname eq $settings->{cap_public_key_name}){
				$public_key = $varvalue
			}
		}	
	}
	$answer_key = encryptKey($r->remote_addr,$trunc . $settings->{internal_masterpid} , $answer_text, $settings->{cap_secret_key} );				
	if ($public_key eq $answer_key && $public_key ne '' && $answer_text ne ''){
	#cap phat cookie 				
		$response = <<EOF;
<html>
<body>
<script>
	document.cookie='$settings->{cookie_name}=$valid_key_code';
	location.reload(true);
</script>
</body>
</html>
EOF
		$r->send_http_header("text/html; charset=utf-8");		
		$r->print($response);		   
		$r->flush;		
		return OK;		
	}	
	#if ($public_key ne $answer_key && $answer_key ne ''){
		#$r->log_error(0,'wrong answer' . $answer_key);
	#}
	show_Cap($r);
	return OK;
}
sub validKey($){
	my($ip_address,$trunc,$salt) = @_;
	return md5_hex($ip_address . $trunc . $salt);	
}
sub generateRandomString(){
   my @chars = ("A".."Z", "a".."z",1..9);
   my $string;
   $string .= $chars[rand @chars] for 1..6;   
   return $string;
}
sub encryptKey($){
	my($ip_address,$trunc,$str,$salt) = @_;
	return md5_hex($ip_address . $trunc . $str . $salt);
}
sub post_data_decode ($) {
    my $data = shift;
    $data =~ tr/+/ /;
    $data =~ s/%([a-fA-F0-9]{2})/pack("C", hex($1))/eg;
    $data =~ s/\x22/&quot;/g;    
    return $data;
}
sub whitelisted_network ($) {
    my $request = shift;
    
    return (defined $settings->{whitelisted_networks} && match_ip($request->remote_addr, $settings->{whitelisted_networks}));    
}

# check if client User-Agent value is whitelisted
sub whitelisted_useragent ($) {
    my $request = shift;

    if (defined $settings->{whitelisted_useragents} && defined $request->header_in('User-Agent')) {
        foreach my $UA (@{$settings->{whitelisted_useragents}}) {
            if ($request->header_in('User-Agent') =~ /$UA/) {
                return 1;
            }
        }
    }
    return 0;
}

# check if requested URI is whitelisted
sub whitelisted_uri ($) {
    my $request = shift;

    if (defined $settings->{whitelisted_uris}) {
        foreach my $URI (@{$settings->{whitelisted_uris}}) {
            if ($request->uri =~ /$URI/) {
                return 1;
            }
        }
    }
    return 0;
}

1;
__END__
