package http302;
our $VERSION = '1.0';

use nginx;
use warnings;
use Digest::MD5 'md5_hex';
use MIME::Base64;
use strict;
my $settings = {};
my $valid_key_code;
my $valid_key;
my $key;
sub handler {
	my $r = shift;					
	init($r);	
	return http302($r);		
}	
sub init($){
	my $request = shift;    
    if (not %{$settings}) {				
		$settings->{http302_url_variable_name} = defined $request->variable('http302_url_variable_name') ? $request->variable('http302_url_variable_name') : 'PK';
		$settings->{http302_secret_key} = defined $request->variable('http302_secret_key') ? $request->variable('http302_secret_key') : '7895642UIVTextoper9';
		$settings->{http302_pass_key} = defined $request->variable('http302_pass_key') ? $request->variable('http302_pass_key') : '118945Uyo9uTSLcMOper7';
		
		$settings->{http302_trunc_amount} = defined $request->variable('http302_trunc_amount') ? $request->variable('http302_trunc_amount') : 300;
		$settings->{http302_trunc_valid_cookie_amount} = defined $request->variable('http302_trunc_valid_cookie_amount') ? $request->variable('http302_trunc_valid_cookie_amount') : 6000;
			
        # Populate settings from Nginx configuration
        $settings->{cookie_name} = defined $request->variable('Roboo_cookie_name') ? $request->variable('Roboo_cookie_name') : 'Anti-Robot';        
        $settings->{challenge_modes} = defined $request->variable('Roboo_challenge_modes') ? $request->variable('Roboo_challenge_modes') : 'SWF';
        $settings->{whitelist} = defined $request->variable('Roboo_whitelist') ? $request->variable('Roboo_whitelist') : '';
        $settings->{charset} = defined $request->variable('Roboo_charset') ? $request->variable('Roboo_charset') : 'UTF-8';
        # Generate whitelist arrays
        if ($settings->{whitelist} ne '') {
            my @whitelisted_networks = ($settings->{whitelist} =~ /IP\(([^)]+)\)/g);
            $settings->{whitelisted_networks} = create_iprange_regexp(@whitelisted_networks) unless (not scalar @whitelisted_networks);
            @{$settings->{whitelisted_useragents}} = ($settings->{whitelist} =~ /UA\('([^']+)'\)/g);
            @{$settings->{whitelisted_uris}} = ($settings->{whitelist} =~ /URI\('([^']+)'\)/g);
        }
        # Get RANDBITS for get_timeseed
        use Config;
        $settings->{internal_randbits} = $Config{randbits};
        no Config;
        # Get master process id
        $settings->{internal_masterpid} = getppid();   		
    }
}
sub http302($)
{	
	my $r = shift; 	
	my $trunc_valid_cookie = int(time / $settings->{http302_trunc_valid_cookie_amount});  		
	$valid_key_code = validKey($r->remote_addr, $trunc_valid_cookie, $settings->{internal_masterpid} . $settings->{http302_pass_key} );			
	if ($r->header_in('Cookie') =~ "$settings->{cookie_name}=$valid_key_code")	{
		return 555;
	}	
	my $trunc = int(time / $settings->{http302_trunc_amount}); 
	$valid_key = encryptKey($r->remote_addr, $trunc . $settings->{internal_masterpid} , $settings->{http302_secret_key} );				
	if (verify($r)){		
		return createCookie($r);
	}	
	return show_http302($r);	
}
sub show_http302($){
	my $r = shift;				
	$r->status(302);	
	$r->header_out('Location',$r->uri . "\?$settings->{http302_url_variable_name}=$valid_key");
	$r->send_http_header("text/html; charset=utf-8");				  
	$r->flush;					
	return 302;	
}
sub verify($){
	my $r = shift;			
	my ($varname, $varvalue);
	foreach my $variable (split(/&/, $r->args)){ 			
		($varname, $varvalue) = split(/=/, $variable);
		$varname = post_data_decode($varname);					
		if ($varname eq $settings->{http302_url_variable_name}){				
			if (defined $varvalue) {							
				$varvalue =~ s/^\s+|\s+$//g; 
				$varvalue = substr( $varvalue, 0, 50 );								
				if ($varvalue eq $valid_key && $varvalue ne ''){										
					return 1;			
				}
				return 0;
			}else{
				return 0;
			}					
		}
	}
	return 0;
}
sub createCookie($){
	my $r = shift;
	my $uri = $r->uri;
	my $response = <<EOF;
<html>
<body>
<script>
	document.cookie = "$settings->{cookie_name}=$valid_key_code";
	location.assign('$uri');
</script>
done
</body>
</html>
EOF
	$r->send_http_header("text/html; charset=utf-8");		
	$r->print($response);		   
	$r->flush;		
	return OK;		
}
sub validKey($){
	my($ip_address,$trunc,$salt) = @_;
	return md5_hex($ip_address . $trunc . $salt);	
}

sub encryptKey($){
	my($ip_address,$trunc,$salt) = @_;
	return md5_hex($ip_address . $trunc . $salt);
}
sub post_data_decode ($) {
    my $data = shift;
    $data =~ tr/+/ /;
    $data =~ s/%([a-fA-F0-9]{2})/pack("C", hex($1))/eg;
    $data =~ s/\x22/&quot;/g;    
    return $data;
}
1;
__END__
